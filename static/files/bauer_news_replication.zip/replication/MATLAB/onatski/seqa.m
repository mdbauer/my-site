function x=seqa(a,b,c);
x=linspace(a,(a+(c-1)*b),c)';
