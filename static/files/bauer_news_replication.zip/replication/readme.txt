Name: Michael D. Bauer
Paper: Nominal Interest Rates and the News. Journal of Money, Credit and Banking, Vol. 47, No. 2-3 (March-April 2015)

This ZIP file contains all the code and data required to replicate the results in the paper.

I. Estimation

Script: estimation.r

Inputs:
\R\dtsm_functions.r ## dynamic term structure functions
\R\init.r ## Read in and format/manipulate FF, ED, Yields data.
\R\news_fns.r ## Functions for news/macro/policy models.
\data\FFdata_final.csv ## Fed Funds Future Data
\data\EDdata_final.csv ## Eurodollar data
\data\le_data_daily.RData ## Yields data

Output:
\estimates\results_yfut_1aa.RData ##Estimation results

II. Analysis -- tables and figures

Script: analysis.r

Inputs:
\R\dtsm_functions.r ## dynamic term structure functions
\R\init.r ## Read in and format/manipulate FF, ED, Yields data.
\R\news_fns.r ## Functions for news/macro/policy models.
\data\dates_announcement.txt ## Macro/policy news dates data.
\data\EDdata_final.csv ## Eurodollar data
\data\FFdata_final.csv ## Fed Funds Future Dat
\data\fed_raw_news_csv.csv ## news dataset

Outputs
\data_dY.csv
\factors_dP.csv
\factors_dX.csv
Figures in R Graphics: Figure 1(pg 305), 2(pg 307), 3(pg 309), 4(pg 312), 5(pg 314), 6(pg 316), 7(pg 317).
Tables in R Graphics: Table 1(pg 315), 2(pg 319)


III. Ontaski's matlab code

Location: \MATLAB\onatski\

Steps:
1.) Open news.m in Matlab and set path to open \data_dY.csv\ -- this is a csv created from running analysis.r
2.) By default line 33, the static column from table 3, is commented out, leaving only the dynamic column.
    To rerun for the static column uncomment line 33, and comment out line 34.
3.) Run news.m, which calls functions and data from other files in \MATLAB\onatski\ in order to replicate table 3.



